﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Lab_Task_1.Models
{
    public class Education
    {
       public string Degree;
       public int Year;
       public string Institute;
       public  float Grade;

    }

}