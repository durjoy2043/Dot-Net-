﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Lab_Task_1.Models
{
    public class Personal_Details
    {
        public string Name;
        public string FathersName;
        public string MothersName;
        public string Gender;
        public string MaritalStatus;
        public string DateOfBirth;
        public string Address;
    }
}