﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Lab_Task_1.Models
{
    public class Index
    {
       public string Name;
       public string Id;
       public string Email;
    }
}