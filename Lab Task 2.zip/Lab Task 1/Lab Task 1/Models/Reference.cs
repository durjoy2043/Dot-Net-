﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Lab_Task_1.Models
{
    public class Reference
    {
        public string Name;
        public string Email;
        public string Contact;
    }
}