﻿using Lab_Task_1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Lab_Task_1.Controllers
{
    public class HomeController : Controller
    {
     
        public ActionResult Index()
        {
            ViewBag.Message = "My Index Details.";
            var Index = new Index();
            Index.Name = "Durjoy Ghosh";
            Index.Id = "20-43511-1";
            Index.Email = "durjoyghosh716@gmail.com";

            var Index1 = new Index[] { Index };
            ViewBag.Ind = Index1;

            return View();
        }

        public ActionResult Education()
        {
            ViewBag.Message = "Your Education page.";
            var Education = new Education();
            Education.Degree = "SSC";
            Education.Year = 2017;
            Education.Institute = "Cambrian School & College-Dhaka";
            Education.Grade = 5.00f;

            var Education1 = new Education();
            Education1.Degree = "HSC";
            Education1.Year = 2019;
            Education1.Institute = "Bangladesh Navy College-Dhaka";
            Education1.Grade = 5.00f;

            var Education3 = new Education();
            Education3.Degree = "BSC in CSE";
            Education3.Year = 2024;
            Education3.Institute = "American International University-Bangladesh";
            Education3.Grade = 4.00f;

            var Edu = new Education[] { Education,Education1,Education3};
            ViewBag.Education = Edu;
            return View();
        }
        public ActionResult Personal_Details ()
        {
            ViewBag.Message = "Your personal_details page.";
            var Personal_Details = new Personal_Details();
            Personal_Details.Name = "Durjoy ghosh";
            Personal_Details.FathersName = "Sudhir Ghosh";
            Personal_Details.MothersName = "Sanchita Ghosh";
            Personal_Details.Gender = "Male";
            Personal_Details.MaritalStatus = "Unmarried";
            Personal_Details.DateOfBirth = "18/01/2001";
            Personal_Details.Address = "Amin Vila,Kuratoli,Dhaka-Bangladesh";

            var PD = new Personal_Details[] { Personal_Details };
            ViewBag.PD= PD;
            return View();
        }

        public ActionResult Projects()
        {
            ViewBag.Message = "Your projects page.";
            var Projects = new Projects();
            Projects.ProjectName = "Java Project - Bank Management System : ";
            Projects.ProjectDescription = "Implemented a robust Bank Management System in Java, offering comprehensive features for account handling, transactions, and customer interactions.";

            var Projects1 = new Projects();
            Projects1.ProjectName = "Graphics Project - Artemis Program:";
            Projects1.ProjectDescription = "Spearheaded the development of the Artemis Program, a graphics project simulating a mission from Earth to the Moon. The program included advanced graphics depicting the rocket launch, with an innovative visualization of population growth during the space journey.";

            var Projects2 = new Projects();
            Projects2.ProjectName = "C# Project - Supershop Management System:";
            Projects2.ProjectDescription = "Designed and implemented a Supershop Management System using C#, focusing on efficient inventory management, sales tracking, and seamless customer interactions.";

            var Projects3 = new Projects();
            Projects3.ProjectName = "WebTech Project - Hotel Management System:";
            Projects3.ProjectDescription = "Developed a user-friendly Hotel Management System using Web Technologies. The project emphasized features such as room booking, customer management, and simplified hotel administration.";

            var Project = new Projects[] { Projects,Projects1,Projects2,Projects3};
            ViewBag.Project = Project;
            return View();
        }
        public ActionResult Reference()
        {
            ViewBag.Message = "Your reference page.";
            var Reference1 = new Reference();
            Reference1.Name = "Fahim Mahmud";
            Reference1.Email = "fahim000@gmail.com";
            Reference1.Contact ="+1234567890";

            var Reference2 = new Reference();
            Reference2.Name = "Tahmeed Hosaain Antor";
            Reference2.Email = "antoryoyo001@example.com";
            Reference2.Contact = "+9876543210";

            var Reference = new Reference[] { Reference1,Reference2};
            ViewBag.References = Reference;

            return View();
        }
    }
}