﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Lab_Task_1.Controllers
{
    public class HomeController : Controller
    {
     
        public ActionResult Index()
        {
            ViewBag.Message = "My Index Details.";

            return View();
        }

        public ActionResult Education()
        {
            ViewBag.Message = "Your education page.";

            return View();
        }
        public ActionResult Personal_Details ()
        {
            ViewBag.Message = "Your personal_details page.";

            return View();
        }

        public ActionResult Projects()
        {
            ViewBag.Message = "Your projects page.";

            return View();
        }
        public ActionResult Reference()
        {
            ViewBag.Message = "Your reference page.";

            return View();
        }
    }
}